
                    if (payload.checksum !== btoa(JSON.stringify(payload.security) + payload.logic).slice(0, 32)) {
                        throw new Error('Content verification failed');
                    }
                    
                    var html = payload.html;
                    var security = payload.security || {};
                    
                    (async function() {
                        try {
                            // Password protection check
                            if (security.password) {
                                const passwordHash = security.password.hash;
                                const passwordHint = security.password.hint;
                                const wrongMessage = security.password.wrongMessage;
                                const maxAttempts = security.password.maxAttempts;
                                const enableMaxAttempts = security.password.enableMaxAttempts;
                                
                                let attempts = 0;
                                if (enableMaxAttempts) {
                                    attempts = localStorage.getItem('passwordAttempts') || 0;
                                    
                                    if (attempts >= maxAttempts) {
                                        document.body.innerHTML = '<h1>Access Blocked</h1><p>Too many incorrect attempts.</p>';
                                        return;
                                    }
                                }
                                
                                async function verifyPassword() {
                                    const userPassword = prompt('This content is password protected.' + 
                                        (passwordHint ? '\nHint: ' + passwordHint : '') + 
                                        '\n\nEnter password:');
                                    
                                    // User clicked Cancel or closed the prompt
                                    if (userPassword === null) {
                                        document.body.innerHTML = '<h1>Access Denied</h1><p>Password required to view this content.</p>';
                                        return false;
                                    }
                                    
                                    // User clicked OK with empty input
                                    if (userPassword === "") {
                                        alert("Password cannot be empty.");
                                        return verifyPassword(); // Show prompt again
                                    }
                                    
                                    // Hash the entered password
                                    const encoder = new TextEncoder();
                                    const data = encoder.encode(userPassword);
                                    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
                                    const hashArray = Array.from(new Uint8Array(hashBuffer));
                                    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
                                    
                                    if (hashHex === passwordHash) {
                                        if (enableMaxAttempts) {
                                            localStorage.setItem('passwordAttempts', 0);
                                        }
                                        return true;
                                    } else {
                                        if (enableMaxAttempts) {
                                            attempts++;
                                            localStorage.setItem('passwordAttempts', attempts);
                                            if (attempts >= maxAttempts) {
                                                document.body.innerHTML = '<h1>Access Blocked</h1><p>Too many incorrect attempts.</p>';
                                                return false;
                                            }
                                            alert(wrongMessage + ` (Attempt ${attempts} of ${maxAttempts})`);
                                        } else {
                                            alert(wrongMessage);
                                        }
                                        return verifyPassword(); // Show prompt again
                                    }
                                }
                                
                                const passwordCorrect = await verifyPassword();
                                if (!passwordCorrect) {
                                    return;
                                }
                            }
                            
                            if (security.expiry) {
                                const expiryDate = new Date(security.expiry.date).getTime();
                                const redirectUrl = security.expiry.redirect;
                                const useOnlineTime = security.expiry.useOnlineTime;
                                const useLocalTime = security.expiry.useLocalTime;
                                let isExpired = false;
                                let timeCheckFailed = false;
                                
                                if (useOnlineTime) {
                                    try {
                                        const response = await fetch('https://timeapi.io/api/Time/current/zone?timeZone=UTC', { cache: 'no-store' });
                                        const data = await response.json();
                                        const currentTime = new Date(data.dateTime).getTime();
                                        if (currentTime > expiryDate) {
                                            isExpired = true;
                                        }
                                    } catch (e) {
                                        console.error("Failed to fetch time:", e);
                                        if (!useLocalTime) {
                                            timeCheckFailed = true;
                                        }
                                    }
                                }
                                
                                if (!timeCheckFailed && useLocalTime && !isExpired) {
                                    if (new Date().getTime() > expiryDate) {
                                        isExpired = true;
                                    }
                                }
                                
                                if (timeCheckFailed) {
                                    alert("Could not verify content expiry. Please try again later.");
                                    return;
                                }
                                
                                if (isExpired) {
                                    alert("This content has expired.");
                                    setTimeout(() => {
                                        window.location.href = redirectUrl;
                                    }, 1000);
                                    return;
                                }
                            }
                            
                            if (security.domain) {
                                const allowedDomain = security.domain.allowed;
                                const domainRedirectUrl = security.domain.redirect;
                                
                                const currentDomain = (function(d) {
                                    return d.replace(/^(https?:\/\/)?(www\.)?/, '').split('/')[0].toLowerCase();
                                })(window.location.hostname);
                                
                                const allowedNormalized = (function(d) {
                                    return d.replace(/^(https?:\/\/)?(www\.)?/, '').split('/')[0].toLowerCase();
                                })(allowedDomain);
                                
                                if (currentDomain !== allowedNormalized && 
                                    !currentDomain.endsWith('.' + allowedNormalized)) {
                                    window.location.href = domainRedirectUrl;
                                    return;
                                }
                            }
                            
                            document.open();
                            document.write(html);
                            document.close();
                        } catch(e) {
                            console.error("Security check failed:", e);
                            document.body.innerHTML = "<h1>Access Denied</h1><p>This content cannot be displayed due to security restrictions.</p>";
                        }
                    })();
                